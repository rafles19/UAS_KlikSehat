package com.example.uas_qrcode2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity

class UserLoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_login)

        val userLoginButton = findViewById<Button>(R.id.userLoginButton)
        userLoginButton.setOnClickListener {
            val phoneNumber = findViewById<EditText>(R.id.userPhoneNumberEditText).text.toString()
            val password = findViewById<EditText>(R.id.userPasswordEditText).text.toString()

            // Lakukan proses login pengguna di sini
            if (phoneNumber.isNotEmpty() && password.isNotEmpty()) {
                // Contoh pindah ke halaman lain setelah login sukses
                startActivity(Intent(this, QRCode::class.java))
            } else {
                // Tampilkan pesan kesalahan
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

class UserHomeActivity : AppCompatActivity() {
    // ...
}
